package com.verizon.service;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.callhistoryteam2.exception.CallNotFoundException;
import com.verizon.dao.ProductDao;
import com.verizon.exception.ProductNotFoundException;
import com.verizon.model.Product;
import jakarta.transaction.Transactional;
@Service
@Transactional
public class ProductService {
	@Autowired
	ProductDao productDao;
	public String addProduct(Product product) {
		productDao.save(product);
		return "Added";
	}
	public   List<Product> getProducts() {
		//List<Product> productList=new ArrayList<>();  //call dao method
		List<Product> productList=productDao.findAll();
		return productList;
	}
	
	public   Product getProduct(Integer id) {
		//Product product=new Product();   //call dao method
		Optional<Product> product=productDao.findById(id);
        return product.orElseThrow(() -> new ProductNotFoundException("Record not found with ID: " + id));

	}
	
	
	public   List<Product> getProductsBetweenLowHigh(Integer low,Integer high) {
		// 		List<Product> productList= new ArrayList<>();// call custom method  
		List<Product> productList=productDao.getProductBetweenLowHigh(low, high);
		if(productList.isEmpty())
		{
			throw new ProductNotFoundException("Record not found between " + low +" and "+high);
		}
		return productList;
	}
	
	
	public Product updatePlan(Integer pid,Product product) {
		////call dao methodreturn new Product() ;
		Product p1=productDao.findById(pid).get();
		if(p1==null)
		{
			throw new ProductNotFoundException("Record not found with ID: " + pid);
		}
		productDao.save(product);
		return productDao.findById(pid).get();
	}
	
	
	public Product deletePlan(Integer pid) {
		////call dao methodreturn new Product();
		Product p1=productDao.findById(pid).get();
		if(p1==null)
		{
			throw new ProductNotFoundException("Record not found with ID: " + pid);
		}
		productDao.deleteById(pid);
		return p1;
		}
	}
