package com.verizon.service;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.verizon.dao.CustomerDao;
import com.verizon.model.Customer;
import jakarta.transaction.Transactional;
@Service
@Transactional
public class CustomerService {
	@Autowired
	CustomerDao customerDao;
	public String addCustomer(Customer customer) {
		customerDao.save(customer);
		//
		return "Added";
	}
	public   List<Customer> getCustomers() {
		//
		//List<Product> productList=new ArrayList<>();
		List<Customer> customerList=customerDao.findAll();
		return customerList;
	}
	public Customer updateCustomer(Integer cid,Customer customer) {
		//
		Customer c=customerDao.findById(cid).get();
		if(c!=null)
			c.setEmail(customer.getEmail());
		return customerDao.findById(cid).get();
		
		//return new Product() ;
	}
	/*public Customer deleteCustomer(Integer cid) {
		//
		//return new Product();
		Customer c=customerDao.findById(cid).get();
		if(c!=null)
			customerDao.deleteById(cid);
		return c;
		
		}*/
	public String deleteCustomer(Integer cid) {
		//
		//return new Product();
		Customer c=customerDao.findById(cid).get();
		if(c!=null)
		{	customerDao.deleteById(cid);
		return "record is deleted";
		}
		else
			return "No record found";
		
	}
}
