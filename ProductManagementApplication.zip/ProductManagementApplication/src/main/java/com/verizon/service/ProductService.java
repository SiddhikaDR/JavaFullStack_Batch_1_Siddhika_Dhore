package com.verizon.service;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.verizon.dao.ProductDao;
import com.verizon.model.Product;
import jakarta.transaction.Transactional;
@Service
@Transactional
public class ProductService {
	@Autowired
	ProductDao productDao;
	public String addProduct(Product product) {
		productDao.save(product);
		//
		return "Added";
	}
	public   List<Product> getProducts() {
		//
		//List<Product> productList=new ArrayList<>();
		List<Product> productList=productDao.findAll();
		return productList;
	}
	public Product updatePlan(Integer pid,Product product) {
		//
		Product p=productDao.findById(pid).get();
		if(p!=null)
			p.setPrice(product.getPrice());
		return productDao.findById(pid).get();
		
		//return new Product() ;
	}
	public Product deletePlan(Integer pid) {
		//
		//return new Product();
		Product p=productDao.findById(pid).get();
		if(p!=null)
			productDao.deleteById(pid);
		return p;
		
		}
	}
