package com.vz.test;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class NewTest {
	 @Test()
	  @Parameters({"id","pwd"})
	  public void sample6(@Optional("abc")String a,@Optional("ab")String d) {
		  System.out.println("test with priority 105");
		  System.out.println(" id "+a+" pwd  "+d);
	  }
	
  @Test(priority=-8)
  public void sample1() {
	  System.out.println("test with priority -8");
  }
  @Test(priority=10)
  public void sample2() {
	  System.out.println("test with priority 10");
  }
  @Test(priority=100)
  public void sample3() {
	  System.out.println("test with priority 100");
  }
  @Test
  public void sample4() {
	  System.out.println("test with priority ");
  }
  @Test(priority=15,enabled=false)//it will not test it bcoz of enabled=false
  public void sample5() {
	  System.out.println("test with priority 15");
  }
 
}