package CaseStudy;

import java.util.*;
public class XYZ {
	int balance=10000;
	/*void debit(int x)
	{
		balance-=x;
	}*/
	void debit(int x)
	{
		if(balance-x>=5000)
		{
			balance-=x;
			System.out.println("successfully debited");
		}
		else
			System.out.println("You don't have sufficient balance");
	}
	void checkBalance()
	{
		System.out.println("your balance is "+balance);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		XYZ a=new XYZ();
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the amt to debit: ");
		int y=sc.nextInt();
		a.debit(y);
		a.checkBalance();
	}

}
