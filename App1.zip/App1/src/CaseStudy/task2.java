package CaseStudy;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class task2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Set hs=new HashSet();
		hs.add("arun");
		hs.add(1);
		hs.add("laxman");
		hs.add("akhil");
		System.out.println(hs);
		Iterator i=hs.iterator();
		while(i.hasNext())
			System.out.println(i.next());
	}

}
