package Interfaces;

public class VehicleLoan implements Loan1,Surity {
	public void applyLoan(String nm,double amt)
	{
		System.out.println("hello "+nm+" you have successfully applied for vehicle "+amt+" loan.");
	}
	public void submission()
	{
		System.out.println("submitted the documents for vehicle");
	}
	public void policy()
	{
		System.out.println("yes you have a surity");
	}
}
