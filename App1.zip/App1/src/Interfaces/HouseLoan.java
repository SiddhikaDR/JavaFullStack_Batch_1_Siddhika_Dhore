package Interfaces;

public class HouseLoan implements Loan1,Surity {
	public void applyLoan(String nm,double amt)
	{
		System.out.println("hello "+nm+" you have successfully applied for "+amt+" loan.");
	}
	public void submission()
	{
		System.out.println("submitted the documnets");
	}
	public void policy()
	{
		System.out.println("yes you have a surity");
	}
}
