package Interfaces;

public interface Loan1 {
	void applyLoan(String nm,double amt);
	void submission();
}
