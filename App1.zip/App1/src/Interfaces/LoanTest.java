package Interfaces;

public class LoanTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Loan1 l;
		HouseLoan h1=new HouseLoan();
		l=h1;
		
		l.applyLoan("raj",1000000);
		l.submission();
		
		Surity s;
		s=h1;
		s.policy();
		
		System.out.println("\n");
		
		VehicleLoan v1=new VehicleLoan();
		l=v1;
		l.applyLoan("raj",1000000);
		l.submission();
		
		s=v1;
		s.policy();
	}

}
