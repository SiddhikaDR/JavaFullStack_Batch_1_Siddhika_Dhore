package Interfaces;

public interface Surity {
	void policy();
}
