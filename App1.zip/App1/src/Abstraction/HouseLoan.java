package Abstraction;

public class HouseLoan extends Loan {
	void applyLoan(String nm,double amt)
	{
		System.out.println("hello "+nm+" you have successfully applied for "+amt+" loan.");
		
	}
	void submission()
	{
		System.out.println("Submitted the documents ");
	}
	int getEmi()
	{
		return 999;
	}
}
