package Abstraction;
public class LoanTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Loan l=new HouseLoan();
		//or HouseLoan l=new HouseLoan();
		l.applyLoan("raj",1000000);
		l.submission();
		System.out.println(l.getEmi());
	}

}
