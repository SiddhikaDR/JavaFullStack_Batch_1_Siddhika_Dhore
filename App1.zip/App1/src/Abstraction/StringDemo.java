package Abstraction;
import java.util.StringTokenizer;

public class StringDemo {

	//private static final String StringTokenize = null;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String nm="Software developer";
		String nm1=new String("java");
		
		System.out.println("length : "+nm.length());
		System.out.println("to upper case :"+nm.toUpperCase());
		System.out.println("concat : "+nm.concat(nm1));
		System.out.println("char at index 2: "+nm.charAt(2));
		System.out.println("index of w :"+nm.indexOf("w"));
		System.out.println("last index of e: "+nm.lastIndexOf("e"));
		System.out.println("compare to "+nm.compareTo(nm1));
		System.out.println("java compare to java"+"java".compareTo("java"));
		System.out.println("java compare to Java"+"java".compareTo("Java"));
		System.out.println("Java compare to java"+"Java".compareTo("java"));
		System.out.println("equals method: "+nm.equals(nm1));
		System.out.println("to compare the address: we use == :"+(nm==nm1));
		
		System.out.println(" \n");
		char ch[]= {'a','b','c','d'};
		String com=new String(ch);
		System.out.println(com);
		
		StringBuffer sb=new StringBuffer("Hello welcome to java");
		System.out.println(sb);
		System.out.println("append: "+sb.append(" abc"));
		System.out.println("insert: "+sb.insert(3, "false"));
		System.out.println("delete: "+sb.delete(3, 5));
		System.out.println("reverse: "+sb.reverse());
		System.out.println("capacity :"+sb.capacity());
		sb.ensureCapacity(50);
		System.out.println(sb.capacity());
		
		System.out.println("\n");
		StringTokenizer st=new StringTokenizer(sb.toString()," ");
		while(st.hasMoreTokens())
			System.out.println(st.nextToken());
		
	}

}
