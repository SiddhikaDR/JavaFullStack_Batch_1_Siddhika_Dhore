package Abstraction;

public abstract class Loan {
	abstract void applyLoan(String name,double amount);
	abstract void submission();
	abstract int getEmi();
}
