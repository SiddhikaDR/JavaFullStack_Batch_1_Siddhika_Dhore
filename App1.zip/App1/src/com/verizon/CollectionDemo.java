package com.verizon;

import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;

public class CollectionDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List l=new ArrayList();
		l.add("arun");
		l.add(1);
		l.add("5");
		l.add("icecream");
		System.out.println(l);
		l.remove(3);
		System.out.println(l);
		System.out.println("length is "+l.size());
		
		ArrayList a=new ArrayList();
		a.add(45);
		a.add(80);
		System.out.println("list is  "+a);
		l.addAll(a);
		System.out.println("union "+l);
		System.out.println(l.containsAll(a));
		//l.clear();
		System.out.println(l);
		
		for(Object o:l)
			System.out.println(o);
		
		System.out.println("using iterator");
		Iterator i=l.iterator();
		while(i.hasNext())
			System.out.println(" "+i.next());
		

	}

}
