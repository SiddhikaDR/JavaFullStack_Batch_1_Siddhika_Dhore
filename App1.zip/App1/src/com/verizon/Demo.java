package com.verizon;

import java.util.Scanner;
public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Welcome to java!!!!");
		System.out.println("Demo class");
		Scanner sc= new Scanner(System.in);
		System.out.println("+,-,*,/"+"   "+"enter an operator: ");
		char ch=sc.next().charAt(0);
		int a,b;
		System.out.println("enter two numbers: ");
		a=sc.nextInt();
		b=sc.nextInt();
		switch(ch)
		{
		case '+' : System.out.println("sum : "+(a+b));break;
		case '-' : System.out.println("sub : "+(a-b));break;
		case '*' : System.out.println("multi : "+(a*b));break;
		case '/' : System.out.println("div : "+(a/b));break;
		default : System.out.println("wrong operator");
		}
		/*int s=0,m=-1;
		int a[]= {1,12,3,4,5};
		for(int i=0;i<a.length;i++)
		{
			System.out.println(" "+a[i]);
			s+=a[i];
			if(m<a[i])
				m=a[i];
		}
		System.out.println("sum of array is: "+s);
		System.out.println("max number is :"+m);
		int b[]=new int[5];
		System.arraycopy(a, 0, b, 0, 5);
		for(int i=0;i<b.length;i++)
		{
			System.out.println(" "+b[i]);
			
		}*/
		/*int x=1;
		while(x<=8)
		{   x++;//x+=2;
			if(x==4)
				continue;//break;
			System.out.println(x);
		}
		for(int x1=0;x1<5;x1++)
			System.out.println(x1);*/
		/*System.out.println("enter the length of rectangle: ");
		int l=sc.nextInt();
		System.out.println("enter the breath of rectangle: ");
		int b=sc.nextInt();
		int a;
		if(l>0 && b>0)
		{
			a=l*b;
			System.out.println("area is "+a);
		}
		else
			System.out.println("enter number greater than 0");*/
		
		//System.out.println("enter your name");
		//String s=sc.nextLine();
		//System.out.println("your name is "+s);
		//System.out.println(args[1]);
	}

}
