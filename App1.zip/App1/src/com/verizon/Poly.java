package com.verizon;

public class Poly {
	
	void area(int x)
	{
		System.out.println("area of square is :"+x*x);
	}
	void area(int l,int b)
	{
		System.out.println("area of rectangle is :"+l*b);
	}
	void area(double r)
	{
		System.out.println("area of circle is : "+3.14*r*r);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Poly p=new Poly();
		p.area(2);
		p.area(3,4);
		p.area(2.5);
	}

}
