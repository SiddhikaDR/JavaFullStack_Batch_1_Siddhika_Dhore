package com.verizon.tms;

public class Employee extends Person {
	String desig;
	Employee()
	{
		System.out.println("in child..");
	}
	public Employee(String desig)
	{
		this();
		this.desig=desig;
		System.out.println(this.desig);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee e1=new Employee("FSD");
		System.out.println(e1);
	}

}
