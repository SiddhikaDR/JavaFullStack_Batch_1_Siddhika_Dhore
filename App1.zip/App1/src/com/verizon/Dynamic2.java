package com.verizon;

public class Dynamic2 extends Dynamic1{
	
	void square(int z)
	{
		System.out.println("perimeter of square is: "+4*z);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Dynamic2 d=new Dynamic2();
		System.out.println("reference of child class ");
		d.square(3);
		
		Dynamic1 d1=new Dynamic1();
		System.out.println("reference of parent class ");
		d1.square(4);
	}

}
