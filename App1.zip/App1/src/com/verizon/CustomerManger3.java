package com.verizon;

import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import javax.swing.text.html.HTMLDocument.Iterator;

public class CustomerManger3 {
	Map<String,String> cn;
	public CustomerManger3()
	{
		cn=new TreeMap();
		cn.put("raj","12345");
		cn.put("arun","3456");
	}
	public void addContact(String s,String s1)
	{
		cn.put(s,s1);
	}
	public void printContact()
	{
		/*for (String key : cn.keySet()) { 
            System.out.println("Key: " + key + ", Value: " + cn.get(key)); */
		System.out.println(cn);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CustomerManger3 c=new CustomerManger3();
		c.addContact("pooja","6789");
		c.printContact();
		
	}

}