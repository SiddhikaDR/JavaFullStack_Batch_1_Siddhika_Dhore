package com.verizon;

import java.util.ArrayList;
import java.util.List;

public class CustomerManager {
	List cn;
	public CustomerManager()
	{
		cn=new ArrayList();
		cn.add("raj");
		cn.add("arun");
	}
	public void addContact(String s)
	{
		cn.add(s);
	}
	public void printContact()
	{
		/*for(String x:cn)
			System.out.print(x+" ");*/
		cn.forEach(x->System.out.print(x+"\n"));
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CustomerManager c=new CustomerManager();
		c.addContact("pooja");
		c.printContact();
		
	}

}
