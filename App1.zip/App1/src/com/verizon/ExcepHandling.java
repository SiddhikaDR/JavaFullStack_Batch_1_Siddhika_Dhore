package com.verizon;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class ExcepHandling {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//int a=10,b=0;
		//int arr[]= {1,2,3};
		
		// single try catch block
		/* try
		{
			int c=a/b;
			System.out.println("answer :"+c);
		}catch(ArithmeticException e)
		{
			System.out.println(e);
		}*/
		
		//nested try catch
		 /*try {
			try {
				int c=a/b;
				System.out.println("ans :"+c);
			}catch(ArithmeticException e2)
			{
				System.out.println(e2.getMessage());
			}
			System.out.println(arr[5]);
		}catch(ArrayIndexOutOfBoundsException e1)
		{
			System.out.println(e1.getMessage());
		}
		System.out.println("done");
*/
		
		//one try with multiple catch
		/*try
		{
			int c=a/b;
			System.out.println("answer :"+c);
		}catch(ArithmeticException e)
		{
			System.out.println(e);
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println(e.getMessage());
		}*/
		
		//try catch with finally
		/*FileReader f = null;
		try {
			f=new FileReader("Demo.txt");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			try {
				f.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}*/
		
		//try with resource
		try(FileReader f=new FileReader("C:\\practice\\Demo.txt");){
			
		}
		catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		/////
		/*try
		{
			int c=a/b;
			System.out.println("answer :"+c);
			System.out.println(arr[5]);
		}
		catch(ArithmeticException | ArrayIndexOutOfBoundsException e2)
		{
			System.out.println(e2.getMessage());
		}*/
		
	}

}
