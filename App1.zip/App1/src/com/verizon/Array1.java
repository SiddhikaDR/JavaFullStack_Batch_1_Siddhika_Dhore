package com.verizon;

import java.util.Arrays;
import java.util.List;

public class Array1 extends Demo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]= {4,2,5,1,9,6};
		for(int x:a)
			System.out.print(x+" ");
		System.out.println("\nafter sorting:");
		Arrays.sort(a);
		for(int x:a)
			System.out.print(x+" ");			
		
		System.out.println("\nindex of element 5 in array : "+Arrays.binarySearch(a, 5));
		
		System.out.println("\nusing foreach method with lambda for list:");
		//Arrays.sort(a);
		List<Integer> l=Arrays.asList(1,2,3,4,5);
		l.forEach(x->System.out.print(x+" "));
		
		System.out.println("\nforeach method with method reference for list:");
		//Arrays.sort(a);
		//List<Integer> l=Arrays.asList(1,2,3,4,5);
		l.forEach(System.out::print);
		//l.forEach(Demo1::show);
		//Demo1 d=new Demo1();
		//show(0);
		
	}

}
