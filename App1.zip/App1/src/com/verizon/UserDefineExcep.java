package com.verizon;

import java.util.Scanner;

class demo2 extends Exception{
	demo2(){
		System.out.println("minimum amt should be 1000");
	}
}

public class UserDefineExcep  {
	public static void main(String[] args) throws demo2 {
		int amt;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the amt: ");
		amt=sc.nextInt();
		if(amt<1000)
			throw new demo2();
		else
			System.out.println("Thank you!!!");
	}
}


