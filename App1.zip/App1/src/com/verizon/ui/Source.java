package com.verizon.ui;

import com.verizon.exception.OperatorException;
import com.verizon.model.Activity;

public class Source {

	public static boolean validate(Activity a) {
		//throw new NullPointerException("the value is null");
		if((a.getOp().equals("+")) && (a.getOp().equals("-")))
				return false;
		else return true;
		//}
		/**/
	}
	public static String doOperation(Activity a1)
	{
		String x=null;
		String x1=null;
		//x=a1.getS1().concat(a1.getS2());
		//return x;
		boolean t=(a1.getOp().equals("+"));
		if(t)
		{
			x=a1.getS1().concat(a1.getS2());
			return x;
		}
		else if((a1.getOp().equals("-")))
			{
			x1=a1.getS1().replaceAll(a1.getS2()," ");
			return x1;
		}
		else
			{System.out.println("can't perform operation");
			return " ";}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Activity a = new Activity("i am ","arun","+");
		//System.out.println(a.getOp().equals("+"));
		Source s=new Source();
		try {
			try
			{if (a.getS1().equals("h") || a.getS2().equals("h"))
				{System.out.println("l");}
			}catch(NullPointerException e)
			{
				System.out.println("the value is null");
			}
			if (!validate(a)) {
				throw new OperatorException("Invalid operator");
			} else {
				System.out.println(" ");
				System.out.println(s.doOperation(a));
			}
		} catch (Exception e) {

		}
		// System.out.println(a.getS1()==null);

	}

}
