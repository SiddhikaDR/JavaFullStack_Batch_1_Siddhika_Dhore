package com.verizon;

import java.util.List;
import java.util.ArrayList;

public class Demo1 {
	static List l;
	public static void show(int x)
	{
		System.out.println("hello "+x);
	}
	public static int removeBook(String a)
	{
		int f=-1;
		if(l.contains(a))
			f=1;
		else f=0;
		if(f==1)
			return 1;
		else return 0;
			
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("hello");
		show(0);
		l=new ArrayList<String>();
		l.add("ar");
		l.add("java");
		System.out.println(l.contains("ar"));
		System.out.println(removeBook("java"));
		
		
		
	}

}
