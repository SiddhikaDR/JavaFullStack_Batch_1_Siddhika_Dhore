package com.verizon;

import java.util.StringJoiner;

public class StringsJoiner {
	public static void main(String[] args) {
		StringJoiner sj=new StringJoiner(",");
		sj.add("Rahul");
		sj.add("Arun");
		sj.add("Raju");
		sj.add("peter");
		System.out.println("string is "+sj);
		System.out.println("string length is "+sj.length());
		
		StringJoiner sj1=new StringJoiner("-");
		sj1.add("Pyhton");
		sj1.add("Java");
		System.out.println("string is "+sj1);
		
		//System.out.println("merge :"+sj.merge(sj1));
		System.out.println("merge :"+sj1.merge(sj));
		System.out.println("string is "+sj1.getClass());
		System.out.println("string is "+sj1.toString().getClass());
		System.out.println("string is "+sj);
	}
}
