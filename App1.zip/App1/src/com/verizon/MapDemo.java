package com.verizon;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

public class MapDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Map<Integer,String> hm=new HashMap<>();
		hm.put(1, "arun");
		hm.put(3, "raj");
		hm.put(4, "arun");
		hm.put(2, "run");
		//hm.put(3, "raj");
		//hm.put(4, "arun");
		System.out.println(hm);
		
		Map<Integer,String> lhm=new LinkedHashMap<>();
		lhm.put(1, "arun");
		lhm.put(3, "raj");
		lhm.put(4, "arun");
		lhm.put(2, "run");
		
		System.out.println("\nlinked hash map\n"+lhm);
		
		System.out.println("\nkey values");
		Set ks=hm.keySet();
		System.out.println(ks);

		System.out.println("\nvalues are");
		Collection vals=hm.values();
		System.out.println(vals);
		
		Set kvs=hm.entrySet();
		Iterator i=kvs.iterator();
		while(i.hasNext())
		{
			Map.Entry e=(Map.Entry)i.next();
			System.out.println(e.getKey()+" "+e.getValue());
		}

	}

}
