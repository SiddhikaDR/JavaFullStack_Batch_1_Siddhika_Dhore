package com.verizon;

import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;

public class SetDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Set<Object> hs=new HashSet();
		hs.add("arun");
		hs.add(1);
		hs.add("laxman");
		hs.add("akhil");
		System.out.println(hs);
		Iterator i=hs.iterator();
		while(i.hasNext())
			System.out.println(i.next());
		
		hs=new LinkedHashSet<>();
		hs.add("arun");
		hs.add(1);
		hs.add("laxman");
		hs.add("akhil");
		hs.add(null);
		System.out.println(hs);
		System.out.println("\nlinked hash set:");
		i=hs.iterator();
		while(i.hasNext())
			System.out.println(i.next());
		
		Set<Object> hs1=new TreeSet<>();
		hs1.add("arun");
		//hs1.add(1);
		hs1.add("laxman");
		hs1.add("akhil");
		System.out.println(hs1);
		System.out.println("\nlinked hash set:");
		 i=hs1.iterator();
		while(i.hasNext())
			System.out.println(i.next());
		

	}

}
