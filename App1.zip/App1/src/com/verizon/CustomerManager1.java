package com.verizon;
import java.util.HashSet;
import java.util.Set;

public class CustomerManager1 {
	Set cn;
	public CustomerManager1()
	{
		cn=new HashSet();
		cn.add("raj");
		cn.add("arun");
	}
	public void addContact(String s)
	{
		cn.add(s);
	}
	public void printContact()
	{
		/*for(String x:cn)
			System.out.print(x+" ");*/
		cn.forEach(x->System.out.print(x+"\n"));
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CustomerManager1 c=new CustomerManager1();
		c.addContact("pooja");
		c.printContact();
		
	}

}

