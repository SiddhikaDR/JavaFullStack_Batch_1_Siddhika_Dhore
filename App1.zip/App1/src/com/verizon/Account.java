package com.verizon;

public class Account {

	int accno;
	protected String name;
	private double balance;
	
	Account()
	{
		accno=1;
		name="abc";
		balance=100;
	}
	
	public Account(int accno, String name) {
		super();
		this.accno = accno;
		this.name = name;
	}

	Account(int accno,String name,double balance)
	{
		this.accno=accno;
		this.name=name;
		this.balance=balance;
	}
	
	void deposite(int amt)
	{
		balance+=amt;
	}
	void withdraw(int amt)
	{
		balance-=amt;
	}
	double getBalance()
	{
		return balance;
	}
}
