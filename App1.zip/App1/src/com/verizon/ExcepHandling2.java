package com.verizon;

import java.io.FileNotFoundException;
import java.io.FileReader;

public class ExcepHandling2 {

	int a[]= {1,2,3,4};
	public void show()throws FileNotFoundException
	{
		FileReader f=new FileReader("C:\\practice\\Demo.txt");
	}
	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		ExcepHandling2 e=new ExcepHandling2();
		e.show();
		System.out.println("done");
	}

}
