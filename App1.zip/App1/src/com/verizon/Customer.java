package com.verizon;

public class Customer {

	private int id;
	String name;
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "Customer [id=" + id + ", name=" + name + "]";
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Customer c=new Customer();
		c.setId(11);
		c.setName("arun");
		System.out.println(c);
		Customer c1=new Customer();
		c1.setId(12);
		c1.setName("pooja");
		System.out.println(c1);
		System.out.println(c.getClass());
		System.out.println(c.hashCode());
		System.out.println(c.equals(c));
	}

}
