package com.verizon.exception;

public class OperatorException extends Exception{
	public OperatorException(String s)
	{
		System.out.println(s);
	}
}
