package com.verizon.util;

public class MyMathDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyMath m=new MyMath();
		System.out.println(m.factorial(4));
		System.out.println(m.isPerfectNumber(7));

	}

}
