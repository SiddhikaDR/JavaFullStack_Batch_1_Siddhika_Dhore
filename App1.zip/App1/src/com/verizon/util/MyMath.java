package com.verizon.util;

public class MyMath {
	public static boolean isPerfectNumber(int n)
	{
		int x=n,y,s=0;
		for(int i=1;i<n;i++)
		{
			if(n%i==0)
				s+=i;
		}
		if(s==n)
			return true;
		else return false;
	}
	public static long factorial(int n)
	{
		long fact=1;
		for(int i=n;i>=1;i--)
		{
			fact*=i;
		}
		return fact;
	}
}
