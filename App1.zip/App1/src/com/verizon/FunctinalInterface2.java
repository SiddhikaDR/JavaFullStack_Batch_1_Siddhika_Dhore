package com.verizon;

//@FunctionalInterface
interface ar1<T>
{
	T operation(T a,T b);
}

public class FunctinalInterface2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ar1<Integer> x=(a,b)->a+b;
		System.out.println("addition : "+x.operation(2, 5));
		
		ar1<Double> x1=(a,b)->a+b;
		System.out.println("multiplication : "+x1.operation(2.45, 5.2324));
		
		/*x=(a,b)->{int c=a-b; return c;};
		System.out.println("subtraction : "+x.operation(2, 5));
		
		x=(a,b)->a*a+b*b;
		System.out.println("addition of square of 2 numbers : "+x.operation(2, 5));
*/
	}

}
