package com.verizon;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class CustomerManager2 {
	Map<String,String> cn;
	public CustomerManager2()
	{
		cn=new HashMap();
		cn.put("raj","12345");
		cn.put("arun","3456");
	}
	public void addContact(String s,String s1)
	{
		cn.put(s,s1);
	}
	public void printContact()
	{
		Set kvs=cn.entrySet();
		Iterator i=kvs.iterator();
		while(i.hasNext())
		{
			Map.Entry e=(Map.Entry)i.next();
			System.out.println(e.getKey()+" "+e.getValue());
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CustomerManager2 c=new CustomerManager2();
		c.addContact("pooja","6789");
		c.printContact();
		
	}

}

