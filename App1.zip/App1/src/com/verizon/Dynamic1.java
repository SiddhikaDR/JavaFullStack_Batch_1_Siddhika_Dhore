package com.verizon;

public class Dynamic1 {
	void square(int x)
	{
		System.out.println("area of square is: "+x*x);
	}
}
