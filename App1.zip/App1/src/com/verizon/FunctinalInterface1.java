package com.verizon;
@FunctionalInterface
interface arith{
	int operation(int a,int b);
}
public class FunctinalInterface1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		arith x=(a,b)->a+b;
		System.out.println("addition : "+x.operation(2, 5));
		
		arith x1=(a,b)->a+b;
		System.out.println("multiplication : "+x1.operation(2, 5));
		
		x=(a,b)->{int c=a-b; return c;};
		System.out.println("subtraction : "+x.operation(2, 5));
		
		x=(a,b)->a*a+b*b;
		System.out.println("addition of square of 2 numbers : "+x.operation(2, 5));
	}

}
