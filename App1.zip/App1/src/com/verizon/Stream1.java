package com.verizon;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class Stream1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			
		List l=Arrays.asList(1,2,3,"abc");
		l.forEach(System.out::println);
		
		List<Integer> l1=Arrays.asList(51,12,33,23,15,45,67,90);
		l1.stream().sorted().limit(5).forEach(x->System.out.print(x+" "));
		
		//Optional<Integer> l2=
		System.out.println("\n sorted n map ");
		l1.stream().sorted().map(x->(x+x)).forEach(x->System.out.print(x+" "));
		
		System.out.println("\n\n to reverse the list");
		l1.stream().sorted(Collections.reverseOrder()).forEach(x->System.out.print(x+" "));
		
		System.out.print("\n\n to largest the list ");
		int a=l1.stream().sorted(Collections.reverseOrder()).findFirst().get();
		System.out.print(a);
		
		System.out.print("\n\n to 2nd largest the list ");
		 a=l1.stream().sorted(Collections.reverseOrder()).skip(1).findFirst().get();
		System.out.print(a);
		
		System.out.print("\n\n to 3rd largest the list ");
		 a=l1.stream().sorted(Collections.reverseOrder()).skip(2).findFirst().get();
		System.out.print(a);
		
		//optinal class
		Optional<String> s=Optional.ofNullable(null);
		if(s.isPresent())
			System.out.println(s.get());
		else System.out.println("\nempty");
		
		//Optional m=l1.stream().sorted());

		Optional<Integer> m=l1.stream().sorted(Collections.reverseOrder()).limit(5).findFirst();
		if(m.isPresent())
			System.out.println(m.get());
		else System.out.println("\nlist is empty");
		
		List<Integer> l2=l1.stream().sorted().collect(Collectors.toList());
		l2.forEach(System.out::println);
	}

}
