package com.verizon;

import java.util.Random;
import java.util.function.Supplier;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
public class Consumer1Function {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Consumer<Integer> x=(a)->System.out.println("Square :"+a*a);
		x.accept(4);
		
		Supplier<Integer> s=()->new Random().nextInt(100);
		System.out.println("random number is "+s.get());
	
		Supplier<Float> s1=()->new Random().nextFloat(100);
		System.out.println("random number is "+s1.get());
		
		Predicate<Integer> p=(a)->a%2==0;
		System.out.println("predicate "+p.test(4));
		
		Function<Integer,Integer> f=(x1)->x1*x1*x1;
		System.out.println("cube: "+f.apply(3));
		
		Function<String,Integer> f1=(x11)->Integer.parseInt(x11);
		System.out.println("age "+(f1.apply("20")+2));
		
		/*Function<String,Integer> f11=(x12)->Integer.parseInt(x12);
		System.out.println("string "+f11.apply("java"));*/
	}

}
