package com.verizon;

public class SavingAccount extends Account{

	String proof,bname;
	
	void show()
	{
		deposite(3000);
		System.out.println(getBalance());
		//System.out.println("acno "+" "+balance);
	}
	@Override
	public String toString() {
		return "SavingAccount [proof=" + proof + ", bname=" + bname + "]";
	}
	public String getBname() {
		return bname;
	}
	public void setBname(String bname) {
		this.bname = bname;
	}
	public static void main(String[] args) {
		SavingAccount sa=new SavingAccount();
		sa.setBname("hdfc");
		sa.show();
		System.out.println(sa);
	}
}
