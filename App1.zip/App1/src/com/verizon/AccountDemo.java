package com.verizon;

public class AccountDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*Account a=new Account();
		a.accno=10;
		a.name="arun";
		a.balance=25000;
		*/
		Account a=new Account();
		Account a1=new Account(12,"raj",20000);
		System.out.println("account name: "+a.accno+" name: "+a.name+" balance is "+a.getBalance());
		System.out.println("account name: "+a1.accno+" name: "+a1.name+" balance is "+a1.getBalance());

	}

}
