package com.verizon.model;

public class Activity {
	private String s1;
	private String s2;
	private String op;
	public Activity()
	{
		s1="i am";
		s2="raj";
		op="+";
	}
	public Activity(String s1,String s2,String op)
	{
		this.s1=s1;
		this.s2=s2;
		this.op=op;
	}
	
	public String getS1() {
		return s1;
	}
	public void setS1(String s1) {
		this.s1 = s1;
	}
	public String getS2() {
		return s2;
	}
	public void setS2(String s2) {
		this.s2 = s2;
	}
	public String getOp() {
		return op;
	}
	public void setOp(String op) {
		this.op = op;
	}
	

}
