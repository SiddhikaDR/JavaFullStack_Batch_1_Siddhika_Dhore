package databaseConnection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class dbConnect {
	
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		//Class.forName("oracle.jdbc.driver.OracleDriver");
		Class.forName("oracle.jdbc.driver.OracleDriver");
		//Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","arun123");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","arun123");
		System.out.println("connection successful");
	}

}
