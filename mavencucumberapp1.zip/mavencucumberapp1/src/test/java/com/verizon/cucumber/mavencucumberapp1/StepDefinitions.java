package com.verizon.cucumber.mavencucumberapp1;

import io.cucumber.java.en.*;

import static org.junit.jupiter.api.Assertions.*;

public class StepDefinitions {

    @Given("{int} cukes in the belly")
    public void anExampleScenario(int cukes) {
    	Belly b1=new Belly();
    	b1.eat(cukes);
    }

    @When("wait for 1 hour")
    public void allStepDefinitionsAreImplemented() {
    	Belly b1=new Belly();
    	b1.waitStep();;
    }

    @Then("belly should growl")
    public void theScenarioPasses() {
    	Belly b1=new Belly();
    	b1.endProcess();
    }

}
