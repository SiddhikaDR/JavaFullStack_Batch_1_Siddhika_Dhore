package com.verizon.cucumber.mavencucumberapp1;

public class Belly {
	public void eat(int cukes)
	{
		System.out.println("step started ");
	}
	public void waitStep()
	{
		System.out.println("waiting for step 1 to complete");
	}
	public void endProcess()
	{
		System.out.println("all steps are executed");
	}
}
