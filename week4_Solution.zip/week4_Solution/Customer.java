class Customer
{
String name;
public Customer()
{
}
public Customer(String st)
{
this.name=st;
}
void displayCustomerName()
{
System.out.println("customer name is :"+name);
}
public static void main(String args[])
{
Customer c=new Customer("Verizon User");
c.displayCustomerName();
}
}