package com.verizon;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import junit.framework.Assert;

class Testapp {
WebDriver driver;
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	void test() {
		driver =new ChromeDriver();
		driver.get("https://www.geeksforgeeks.org/");
		Assert.assertEquals(driver.getTitle(),"GeeksforGeeks | A computer science portal for geeks");
		String title=driver.getTitle();
		System.out.println("page title : "+title);
		String tagName=driver.findElement(By.id("comp")).getTagName();
		System.out.println("tag name of id 'comp' is " +tagName);
		driver.quit();
		//fail("Not yet implemented");
	}

}
