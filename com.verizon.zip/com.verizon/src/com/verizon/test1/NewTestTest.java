package com.verizon.test1;

import org.testng.annotations.Test;

public class NewTestTest {

  @Test
  public void loginTestTest() {
    throw new RuntimeException("Test not implemented");
  }
}
