package com.verizon;


import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class CustomerTest {

	@Test
	void test() {
		Customer c=new Customer();
		assertEquals(c.getBalance(),1000);
		//fail("Not yet implemented");
	}

}
