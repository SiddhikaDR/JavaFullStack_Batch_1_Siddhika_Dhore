package com.verizon;

public class Account {

	public int getBalanace() {
		// TODO Auto-generated method stub
		return 200;
	}

}
