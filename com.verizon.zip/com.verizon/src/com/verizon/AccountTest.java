package com.verizon;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class AccountTest {

	@Test
	void test() {
		Account a=new Account();
		assertEquals(a.getBalanace(),1000);
		//fail("Not yet implemented");
	}

}
