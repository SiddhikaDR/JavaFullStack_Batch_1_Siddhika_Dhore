package com.verizon;

public class Customer {

	public int getBalance() {
		// TODO Auto-generated method stub
		//return null;
		return 200;
	}

}
