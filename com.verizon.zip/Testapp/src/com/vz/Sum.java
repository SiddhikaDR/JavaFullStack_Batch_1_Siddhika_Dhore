package com.vz;

public class Sum {
	
	public int add(int a,int b) {
		return a+b;
	}
}
