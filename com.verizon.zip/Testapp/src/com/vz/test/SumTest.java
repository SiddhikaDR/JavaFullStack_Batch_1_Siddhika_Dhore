package com.vz.test;

import org.testng.annotations.Test;
import org.testng.annotations.Test;

public class SumTest {

  @Test
  public void addTest() {
    //throw new RuntimeException("Test not implemented");
  }
}
