package demo;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class CalculatorTest2 {

	Calculator c;
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		System.out.println("before all the case");
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
		System.out.println("after all the case");
	}

	@BeforeEach
	void setUp() throws Exception {
		 c=new Calculator();
		System.out.println("object is created for each");
	}

	@AfterEach
	void tearDown() throws Exception {
		c=null;
		System.out.println("test case object is teared down");
	}

	@Test
	void testSum() {
		//fail("Not yet implemented");
		
		assertEquals(c.sum(4, 3),7);
	}

	@Test
	void testSub() {
		//fail("Not yet implemented");
		assertEquals(c.sub(4, 3),1);
	}

}
