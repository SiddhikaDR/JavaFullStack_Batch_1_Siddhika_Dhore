package demo;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class CalculatorTest1 {

	@Test
	void testSum() {
		//fail("Not yet implemented");
		Calculator c=new Calculator();
		assertEquals(c.sum(4, 3),7);
	}

	@Test
	void testSub() {
		//fail("Not yet implemented");
		Calculator c=new Calculator();
		assertEquals(c.sub(4, 3),1);
	}

}
