package codes;

public class Course {
	int cid;
	String cname;
	double fee;
	Course(int i,String s,double f)
	{
		this.cid=i;
		this.cname=s;
		this.fee=f;
	}
	@Override
	public String toString() {
		return "Course [cid=" + cid + ", cname=" + cname + ", fee=" + fee + "]";
	}

}
