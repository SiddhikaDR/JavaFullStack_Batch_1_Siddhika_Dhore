package codes;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class CourseDemo {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*Course x=new Course(12,"java",2500.00);
		CourseService z=new CourseServiceimp();
		System.out.println(z.addCourse(x));
		List<Course> cl1=z.listCourse();
		
		for(Course c1:cl1)
			System.out.println(c1);
		System.out.println(cl1);*/
		int ch;
		CourseService z;
		 z=new CourseServiceimp();
		do
		{
			System.out.println("MENU\n\n1. ADD\n2.DELETE\n3. UPDATE\n4. LIST OUT\n5. EXIT\n\n Enter your choice: ");
			Scanner sc=new Scanner(System.in);
			ch=sc.nextInt();
			switch(ch)
			{
			case 1: int ob1;
			String ob2;
			double ob3;
				System.out.println("enter the id of course: ");
				 ob1=sc.nextInt();
				System.out.println("enter the course name: ");
				ob2=sc.next();
				System.out.println("enter the fee: ");
				 ob3=sc.nextDouble();
				Course c=new Course(ob1,ob2,ob3);
				System.out.println(z.addCourse(c));
			/*Course x=new Course(12,"java",2500.00);Course x1=new Course(14,"c++",1500.00);
			
			System.out.println(z.addCourse(x));System.out.println(z.addCourse(x1));*/
			break;
			case 2: System.out.println("Enter the  id to delete: ");
					int d=sc.nextInt();
					System.out.println( z.deleteCourse(d));
					break;
			case 3: System.out.println("Enter the  id to update: ");
					int d1=sc.nextInt();
					
					System.out.println( z.updateCourse(d1));
					break;
			case 4: List<Course> cl1=z.listCourse();
			
			for(Course c1:cl1)
				System.out.println(c1);
			//System.out.println(cl1);
			break;
			case 5: break;
			}
			
		}while(ch!=5);
	}

}
