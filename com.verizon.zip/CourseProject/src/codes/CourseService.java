package codes;

import java.util.List;

public interface CourseService {
	String addCourse(Course c);
	String deleteCourse(Integer i);
	String updateCourse(Integer i);
	List<Course> listCourse();
}
