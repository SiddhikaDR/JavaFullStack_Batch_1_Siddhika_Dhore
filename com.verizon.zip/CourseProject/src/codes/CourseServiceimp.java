package codes;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class CourseServiceimp implements CourseService{
	List<Course> cl=new ArrayList<>();
	public String addCourse(Course c)
	{
		cl.add(c);
		//System.out.println(cl);
		return "successfully added the course";
	}
	public String deleteCourse(Integer i)
	{
		//System.out.println("id got is "+i);
		Iterator i1=cl.iterator();
		
 		while(i1.hasNext())
		{
			Course c2=(Course)i1.next();
			if(c2.cid==i)
				i1.remove();
		}
		return "deleted the course ";
	}
	public String updateCourse(Integer i)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the fees: ");
		double dd=sc.nextDouble();
		Iterator i1=cl.iterator();
		
 		while(i1.hasNext())
		{
			Course c2=(Course)i1.next();
			if(c2.cid==i)
				c2.fee=dd;
		}
		
		return "updated the course ";
	}
	public List<Course> listCourse()
	{
		return cl;
	}

}
