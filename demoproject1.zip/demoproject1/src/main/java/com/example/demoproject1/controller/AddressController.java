package com.example.demoproject1.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demoproject1.module.Address;
import com.example.demoproject1.service.AddressService;

//@RestController
public class AddressController {
	@Autowired
	AddressService addressService;
	
	@GetMapping("/address")
	public List<Address> getAllDetail()
	{
		List<Address> l1=addressService.getAddress();
		return l1;
	}
	
	@PostMapping("/address")
	public String addAddress(@RequestBody Address address)
	{
		return addressService.addStudent(address);
	}
}