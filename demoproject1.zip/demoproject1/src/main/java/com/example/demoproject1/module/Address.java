package com.example.demoproject1.module;

import java.util.HashSet;
import java.util.Set;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;

@Entity
public class Address {
	@Id
	Integer aid;
	@Column
	Integer laneNo;
	Integer buildingNo;
	public Address()
	{
		
	}
	public Address(Integer aid, Integer laneNo, Integer buildingNo) {
		super();
		this.aid = aid;
		this.laneNo = laneNo;
		this.buildingNo = buildingNo;
	}
	public Integer getAid() {
		return aid;
	}
	public void setAid(Integer aid) {
		this.aid = aid;
	}
	public Integer getLaneNo() {
		return laneNo;
	}
	public void setLaneNo(Integer laneNo) {
		this.laneNo = laneNo;
	}
	public Integer getBuildingNo() {
		return buildingNo;
	}
	public void setBuildingNo(Integer buildingNo) {
		this.buildingNo = buildingNo;
	}
	@Override
	public String toString() {
		return "Address [aid=" + aid + ", laneNo=" + laneNo + ", buildingNo=" + buildingNo + "]";
	}
	
	/*
	 * @OneToMany(mappedBy="address",cascade=CascadeType.ALL) private Set<Employee>
	 * employees=new HashSet<>(); public Set<Employee> getEmployees() { return
	 * employees; } public void setEmployees(Set<Employee> employees) {
	 * this.employees = employees; }
	 */}
