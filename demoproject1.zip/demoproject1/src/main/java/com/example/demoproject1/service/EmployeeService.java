package com.example.demoproject1.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demoproject1.dao.EmployeeDao;
import com.example.demoproject1.module.Employee;

@Service
public class EmployeeService {
	@Autowired
	EmployeeDao employeeDao;
	public List<Employee> getEmployees() {
		// TODO Auto-generated method stub
		List<Employee> l1=employeeDao.findAll();
		return l1;
	}
	public String addEmployee(Employee employee) {
		// TODO Auto-generated method stub
		employeeDao.save(employee);
		return "added employee";
	}
}
