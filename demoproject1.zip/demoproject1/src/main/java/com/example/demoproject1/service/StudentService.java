package com.example.demoproject1.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demoproject1.dao.StudentDao;
import com.example.demoproject1.module.Student;

@Service
public class StudentService {
	@Autowired
	StudentDao studentDao;
	
	public String addStudent(Student student) {
		// TODO Auto-generated method stub
		studentDao.save(student);
		return "added";
	}
	public List<Student> getAllStudent() {
		// TODO Auto-generated method stub
		return studentDao.findAll();
	}
	

}
