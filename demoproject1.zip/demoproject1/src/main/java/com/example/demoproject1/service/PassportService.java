package com.example.demoproject1.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demoproject1.dao.PassportDao;
import com.example.demoproject1.module.Passport;

@Service
public class PassportService {
	
	@Autowired
	PassportDao passportDao;
	public List<Passport> getAllPassport() {
		// TODO Auto-generated method stub
		List<Passport> l1=passportDao.findAll();
		return l1;
	}
	public String addPassport(Passport passport) {
		// TODO Auto-generated method stub
		passportDao.save(passport);
		return "Added passport";
	}

}
