package com.example.demoproject1.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demoproject1.module.Employee;
import com.example.demoproject1.service.EmployeeService;


@RestController
public class EmployeeController {
	@Autowired
	EmployeeService employeeService;
	
	@GetMapping("/employee1")
	public List<Employee> getAllDetail()
	{
		List<Employee> l1=employeeService.getEmployees();
		return l1;
	}
	
	@PostMapping("/employee1")
	public String addEmployee(@RequestBody Employee employee)
	{
		return employeeService.addEmployee(employee);
	}
}
