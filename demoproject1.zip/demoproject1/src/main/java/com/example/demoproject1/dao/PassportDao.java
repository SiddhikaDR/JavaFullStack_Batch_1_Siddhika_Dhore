package com.example.demoproject1.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demoproject1.module.Passport;

@Repository
public interface PassportDao extends JpaRepository<Passport,Integer>{

}
