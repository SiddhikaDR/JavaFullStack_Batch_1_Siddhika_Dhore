package com.example.demoproject1.module;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Passport {
	@Id
	Integer pno;
	@Column
	String type;
	String expiryDate;
	public Passport()
	{
		
	}
	public Passport(Integer pno, String type, String expiryDate) {
		super();
		this.pno = pno;
		this.type = type;
		this.expiryDate = expiryDate;
	}
	public Integer getPno() {
		return pno;
	}
	public void setPno(Integer pno) {
		this.pno = pno;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}
	@Override
	public String toString() {
		return "Passport [pno=" + pno + ", type=" + type + ", expiryDate=" + expiryDate + "]";
	}
	
	
	

}
