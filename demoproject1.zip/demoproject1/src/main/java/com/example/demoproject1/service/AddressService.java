package com.example.demoproject1.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demoproject1.dao.AddressDao;
import com.example.demoproject1.module.Address;

@Service
public class AddressService {
	@Autowired
	AddressDao addressDao;
	public List<Address> getAddress() {
		// TODO Auto-generated method stub
		List<Address> l1=addressDao.findAll();
		return l1;
	}
	public String addStudent(Address address) {
		// TODO Auto-generated method stub
		addressDao.save(address);
		return "added address";
	}

}
