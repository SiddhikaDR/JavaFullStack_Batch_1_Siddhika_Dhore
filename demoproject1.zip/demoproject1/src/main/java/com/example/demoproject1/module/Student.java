package com.example.demoproject1.module;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;

@Entity
public class Student {
	@Id
	Integer studentId;
	@Column
	String sname;
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="pno")
	private Passport passport;
	
	public Passport getPassport() {
		return passport;
	}
	public void setPassport(Passport passport) {
		this.passport = passport;
	}
	public Student()
	{
		
	}
	public Student(Integer studentId, String sname) {
		super();
		this.studentId = studentId;
		this.sname = sname;
	}
	public Integer getStudentId() {
		return studentId;
	}
	public void setStudentId(Integer studentId) {
		this.studentId = studentId;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	@Override
	public String toString() {
		return "Student [studentId=" + studentId + ", sname=" + sname + "]";
	}
	
}
